import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as $ from 'jquery';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';

import { NotifyRouteService } from '../../../../providers/notify-route.service';

@Component({
    selector: 'backup-complete',
    templateUrl: './backup-complete.html',
})

export class BackupCompleteComponent implements OnInit {
    private subscription: Subscription;
    backupPop = false;

    constructor(private el: ElementRef,
        private notifyRouteService: NotifyRouteService,
        private router: Router) { }

    ngOnInit() {
        $(this.el.nativeElement).find('.content').addClass('fadeIn animated speed700');

        this.subscription = this.notifyRouteService.notifyObservable$.subscribe((res) => {
            if (res.hasOwnProperty('option') && res.option === 'animateDestroy') {
                $(this.el.nativeElement).find('.content').addClass('fadeOut animated speed700');
            }
        });
    }

    changeRoute(event, path, speed) {
        this.notifyRouteService.notifyOther({ option: 'animateDestroy', value: { speed: speed } });
        setTimeout(() => {
            this.router.navigate([path]);
        }, speed);
    }

    togglePop() {
        this.backupPop = !this.backupPop;
    }
}
