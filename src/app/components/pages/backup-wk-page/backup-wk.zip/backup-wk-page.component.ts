import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as $ from 'jquery';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';

import { NotifyRouteService } from '../../../providers/notify-route.service';

@Component({
    selector: 'backup-wk',
    templateUrl: './backup-wk-page.component.html',
    host: {
        class: 'view'
    }
})

export class BackupPageComponent implements OnInit {
    private subscription: Subscription;
    constructor(private el: ElementRef,
        private notifyRouteService: NotifyRouteService,
        private router: Router) { }

    ngOnInit() {
        var time = 50;
        $(this.el.nativeElement).find('.row').each(function () {
            var elem = this;
            $(elem).addClass('hidden');
        });

        $(this.el.nativeElement).find('.row').each(function () {
            var elem = this;
            setTimeout(function () {
                $(elem).removeClass('hidden');
                $(elem).addClass('fadeInLeft animated speed700');
            }, time);
            time += 50;
        });

        this.subscription = this.notifyRouteService.notifyObservable$.subscribe((res) => {
            if (res.hasOwnProperty('option') && res.option === 'animateDestroy') {
                $(this.el.nativeElement).addClass('fadeOutRight animated speed700');
            }
        });
    }

    changeRoute(event, path, speed) {
        this.notifyRouteService.notifyOther({ option: 'animateDestroy', value: { speed: speed } });
        setTimeout(() => {
            this.router.navigate([path]);
        }, speed);
    }
}
